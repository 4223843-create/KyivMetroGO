import { STORAGE_KEYS, Storage } from '@core/storage.js';

const root = document.documentElement;

export function applyTheme(theme) {
  const css = document.createElement('style');
  css.textContent = '*, *::before, *::after { transition: none !important; }';
  document.head.appendChild(css);

  root.setAttribute('data-theme', theme);
  Storage.set(STORAGE_KEYS.THEME, theme);

  const t = document.getElementById('settingsThemeToggle');
  if (t) t.checked = theme === 'dark';

  requestAnimationFrame(() => requestAnimationFrame(() => css.remove()));
}